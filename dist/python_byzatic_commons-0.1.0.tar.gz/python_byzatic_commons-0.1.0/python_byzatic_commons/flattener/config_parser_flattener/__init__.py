#
#
#

# interfaces
from .ConfigParserFlattener import ConfigParserFlattener

__all__ = [
    'ConfigParserFlattener'
]
