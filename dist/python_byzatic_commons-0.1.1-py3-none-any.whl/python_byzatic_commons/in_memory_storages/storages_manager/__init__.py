#
#
#

# interfaces
from python_byzatic_commons.in_memory_storages.storages_manager.StoragesManager import StoragesManager

__all__ = [
    'StoragesManager'
]