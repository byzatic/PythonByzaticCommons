#
#
#

# interfaces
from python_byzatic_commons.flattener.json_flattener.JsonFlattener import JsonFlattener

__all__ = [
    'JsonFlattener'
]
