#
#
#

# interfaces
from python_byzatic_commons.crud.interfaces.KeyValueCRUDInterface import KeyValueCRUDInterface

__all__ = [
    'KeyValueCRUDInterface'
]
