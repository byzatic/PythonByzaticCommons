#
#
#

# interfaces
from .StoragesManager import StoragesManager

__all__ = [
    'StoragesManager'
]